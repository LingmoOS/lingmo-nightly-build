#ifndef DPLATFORMTHEME_H
#define DPLATFORMTHEME_H


class DPlatformTheme
{
public:
    DPlatformTheme();
};

#endif // DPLATFORMTHEME_H
