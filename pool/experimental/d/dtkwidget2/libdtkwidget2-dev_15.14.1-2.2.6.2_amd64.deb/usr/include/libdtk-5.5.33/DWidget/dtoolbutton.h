#ifndef DTOOLBUTTON_H
#define DTOOLBUTTON_H

#include "dtkwidget_global.h"
#include <QToolButton>

DWIDGET_BEGIN_NAMESPACE

using DToolButton = QToolButton;
using GToolButton = QToolButton;

DWIDGET_END_NAMESPACE

#endif // DTOOLBUTTON_H
