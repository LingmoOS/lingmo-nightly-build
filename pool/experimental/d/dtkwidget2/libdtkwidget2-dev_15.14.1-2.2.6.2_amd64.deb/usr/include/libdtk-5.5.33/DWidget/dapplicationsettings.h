#ifndef DAPPLICATIONSETTINGS_H
#define DAPPLICATIONSETTINGS_H

#include "dtkwidget_global.h"

DWIDGET_BEGIN_NAMESPACE

class DApplicationSettings
{
public:
    DApplicationSettings();
};

DWIDGET_END_NAMESPACE

#endif // DAPPLICATIONSETTINGS_H
