#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "LingmoUI" for configuration "None"
set_property(TARGET LingmoUI APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(LingmoUI PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_NONE "Qt5::Qml;Qt5::Quick;Qt5::QuickControls2;Qt5::X11Extras;KF5::WindowSystem"
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libLingmoUI.so"
  IMPORTED_SONAME_NONE "libLingmoUI.so"
  )

list(APPEND _cmake_import_check_targets LingmoUI )
list(APPEND _cmake_import_check_files_for_LingmoUI "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libLingmoUI.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
